# Raspberry Pi SIM Module Library

This is a simple library written in python for Raspberry Pi Sim/GSM/GPRS Module - **SIM900 and SIM800 Series**. I have tested it on **SIM900A** and **SIM800C**

*Note: This library written completely for my own project use and to help those who are struggling to setting up their own. I do not guarantee its stability and I am not willing to take any risk. So use this code on your own risk.*

Soon I am Going to write a instruction on it. 

I forked the base from this module [IteadSIM800](https://github.com/lamondlab/IteadSIM800)